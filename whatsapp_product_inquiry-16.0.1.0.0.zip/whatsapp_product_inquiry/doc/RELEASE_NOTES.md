## Module <whatsapp_product_inquiry>

#### 06.01.2024
#### Version 16.0.1.0.0
#### ADD

- Initial commit for Whatsapp Product Inquiry In Website
